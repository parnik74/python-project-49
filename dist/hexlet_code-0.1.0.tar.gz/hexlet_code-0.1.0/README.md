### Hexlet tests and linter status:
[![Actions Status](https://github.com/parnik74/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/parnik74/python-project-49/actions)
<a href="https://codeclimate.com/github/parnik74/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4d70812256be7dac6808/maintainability" /></a>

<a href="https://asciinema.org/a/ivs5GB3Dl3ith5OriRu5bgeA9" target="_blank"><img src="https://asciinema.org/a/ivs5GB3Dl3ith5OriRu5bgeA9.svg" /></a>

[![brain-calc script demo](https://asciinema.org/a/RVSFs0dKvHYFLlIDgPeuVqy8T.svg)](https://asciinema.org/a/RVSFs0dKvHYFLlIDgPeuVqy8T)

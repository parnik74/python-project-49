from .brain_games import user_name, welcome_user
import prompt
import random


def ask_user():
    correct_answers = 0
    while correct_answers < 3:
        number_1 = random.randint(1, 20)
        number_2 = random.randint(1, 20)
        print("Find the greatest common divisor of given numbers.")
        # answer = prompt.string(f"Question: {number_1} {number_2} ")
        # while a != 0 and b != 0:
        if number_1 > number_2:
            number_1 = number_1 % number_2
        else:
            number_2 = number_2 % number_1
        print(number_1 + number_2)


def main():
    welcome_user()
    ask_user()


if __name__ == "__main__":
    main()

from .brain_games import *
import prompt
import random

def check_math(x, number_1, number_2):
  if x == '+':
    result = number_1 + number_2
  elif x == '-':
    result = number_1 - number_2
  else:
    result = number_1 * number_2

def ask_user():
    correct_answers = 0
    while correct_answers < 3:
      operators = (["+", "-", "*"])
      random_operator = (random.choice(operators))
      number_1 = random.randint(0,10)
      number_2 = random.randint(0,10)
      if random_operator == '+':
        result = number_1 + number_2
      elif random_operator == '-':
        result = number_1 - number_2
      else:
        result = number_1 * number_2
      answer = prompt.string(f"Question: {number_1} {random_operator} {number_2} ")
      # result = check_math(random_operator, number_1, number_2)
      if answer == result:
        print('Correct!')
        correct_answers += 1
      # elif answer == 'no' and (number % 2) != 0:
      #   correct_answers += 1
      #   print('Correct!')
      # elif answer == 'no' and (number % 2) == 0:
      #   correct_answers = 0
      #   print(f"'no' is wrong answer ;(. Correct answer was 'yes'.\nLet's try again, {user_name}!")
      # elif answer == 'yes' and (number % 2) != 0:
      #   correct_answers = 0
      #   print(f"'yes' is wrong answer ;(. Correct answer was 'no'.\nLet's try again, {user_name}!")
      # else:
      #    print(f"\nWrong answer ;(. \nLet's try again, {user_name}!")
    print(f"Congratulations, {user_name}!")

def calculation():
  if random_operator == '+':
     result = number_1 + number_2
  elif random_operator == '-':
     result = number_1 - number_2
  else:
     result = number_1 * number_2

def main():
    welcome_user()
    ask_user()
    

if __name__ == "__main__":
    main()